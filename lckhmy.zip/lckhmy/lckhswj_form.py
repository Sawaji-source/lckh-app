import tkinter as tk
from tkinter import ttk
from tkcalendar import DateEntry
from reportlab.lib import colors
from reportlab.lib.pagesizes import landscape, A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
import os
import subprocess
from datetime import datetime

class LCKHForm:
    def __init__(self, root):
        self.root = root
        self.root.title("LCKH Form")
        self.root.geometry("800x600")

        # Create input fields
        self.create_input_fields()
        
        # Create table for tasks
        self.create_task_table()
        
        # Create submit button
        self.submit_btn = ttk.Button(root, text="Generate PDF", command=self.generate_pdf)
        self.submit_btn.pack(pady=10)

    def create_input_fields(self):
        # Personal info frame
        info_frame = ttk.LabelFrame(self.root, text="Personal Information", padding=10)
        info_frame.pack(fill="x", padx=10, pady=5)

        # Input fields
        labels = ["Nama:", "NIP:", "Jabatan:", "Wilayah Kerja:"]
        self.entries = {}
        
        for i, label in enumerate(labels):
            ttk.Label(info_frame, text=label).grid(row=i, column=0, sticky="w", pady=2)
            self.entries[label] = ttk.Entry(info_frame, width=40)
            self.entries[label].grid(row=i, column=1, sticky="w", pady=2)

        # Date picker
        ttk.Label(info_frame, text="Tanggal:").grid(row=len(labels), column=0, sticky="w", pady=2)
        self.date_picker = DateEntry(info_frame, width=20, background='darkblue',
                                   foreground='white', borderwidth=2)
        self.date_picker.grid(row=len(labels), column=1, sticky="w", pady=2)

    def create_task_table(self):
        # Task frame
        task_frame = ttk.LabelFrame(self.root, text="Tugas", padding=10)
        task_frame.pack(fill="both", expand=True, padx=10, pady=5)

        # Table headers
        columns = ("No", "Tugas Pokok", "Kegiatan", "Output", "Jumlah", "Keterangan")
        self.task_tree = ttk.Treeview(task_frame, columns=columns, show="headings")
        
        for col in columns:
            self.task_tree.heading(col, text=col)
            self.task_tree.column(col, width=100)

        self.task_tree.pack(fill="both", expand=True)

        # Add and Delete buttons
        btn_frame = ttk.Frame(task_frame)
        btn_frame.pack(pady=5)
        
        ttk.Button(btn_frame, text="Tambah Tugas", command=self.add_task).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="Hapus Tugas", command=self.delete_task).pack(side="left")

    def add_task(self):
        # Create a new window for task input
        task_window = tk.Toplevel(self.root)
        task_window.title("Tambah Tugas")
        task_window.geometry("400x300")

        entries = {}
        labels = ["Tugas Pokok", "Kegiatan", "Output", "Jumlah", "Keterangan"]
        
        for i, label in enumerate(labels):
            ttk.Label(task_window, text=label).pack(pady=2)
            entries[label] = ttk.Entry(task_window, width=40)
            entries[label].pack(pady=2)

        def save_task():
            values = (len(self.task_tree.get_children()) + 1,)
            values += tuple(entries[label].get() for label in labels)
            self.task_tree.insert("", "end", values=values)
            task_window.destroy()

        ttk.Button(task_window, text="Simpan", command=save_task).pack(pady=10)

    def delete_task(self):
        selected_item = self.task_tree.selection()
        if selected_item:
            self.task_tree.delete(selected_item)
            # Renumber remaining items
            for i, item in enumerate(self.task_tree.get_children(), 1):
                values = self.task_tree.item(item)["values"]
                values = list(values)
                values[0] = i
                self.task_tree.item(item, values=values)

    def generate_pdf(self):
        filename = f"LCKH_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        doc = SimpleDocTemplate(filename, pagesize=landscape(A4), rightMargin=30, leftMargin=30,
                              topMargin=10, bottomMargin=10)
        
        elements = []
        styles = getSampleStyleSheet()
        
        # Add custom style for wrapped text in tables
        styles.add(ParagraphStyle(
            name='TableCell',
            fontSize=10,
            leading=12,
            spaceBefore=0,
            spaceAfter=0,
        ))

        # Add custom styles for titles
        styles.add(ParagraphStyle(
            name='CustomTitle',
            fontSize=14,
            alignment=1,  # Center alignment
            spaceAfter=0,
            spaceBefore=0,
            leading=16,
        ))

        # Title and subtitles with adjusted spacing
        title = Paragraph("LAPORAN CAPAIAN KINERJA HARIAN", styles['CustomTitle'])
        subtitle = Paragraph("PEGAWAI PEMERINTAH DENGAN PERJANJIAN KERJA (PPPK)", styles['CustomTitle'])
        year_subtitle = Paragraph(f"KABUPATEN BENGKAYANG TAHUN {self.date_picker.get_date().strftime('%Y')}", 
                                styles['CustomTitle'])
        elements.extend([title, subtitle, year_subtitle])
        elements.append(Spacer(1, 10))  # Add spacing between title and personal info

        # Personal info with wrapped text - adjust spacing and alignment
        data = [
            ["Nama", ":", Paragraph(self.entries["Nama:"].get(), styles['TableCell'])],
            ["NIP", ":", Paragraph(self.entries["NIP:"].get(), styles['TableCell'])],
            ["Jabatan", ":", Paragraph(self.entries["Jabatan:"].get(), styles['TableCell'])],
            ["Wilayah Kerja", ":", Paragraph(self.entries["Wilayah Kerja:"].get(), styles['TableCell'])],
            ["Hari/Tanggal", ":", Paragraph(self.date_picker.get_date().strftime("%d %B %Y"), styles['TableCell'])]
        ]

        info_table = Table(data, colWidths=[80, 15, 600])
        info_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
            ('TOPPADDING', (0, 0), (-1, -1), 0),
            ('LEFTPADDING', (0, 0), (-1, -1), 2),    # Added left padding of 2
        ]))
        elements.append(info_table)
        elements.append(Spacer(1, 10))  # Reduced spacing before task table

        # Tasks table with wrapped text and adjusted column widths
        headers = ["No", "Tugas Pokok", "Kegiatan", "Output", "Jumlah", "Keterangan"]
        task_data = [[Paragraph(str(header), styles['TableCell']) for header in headers]]
        
        for item in self.task_tree.get_children():
            values = list(self.task_tree.item(item)["values"])
            wrapped_values = [
                str(values[0]),  # No
                Paragraph(str(values[1]), styles['TableCell']),  # Tugas Pokok
                Paragraph(str(values[2]), styles['TableCell']),  # Kegiatan
                Paragraph(str(values[3]), styles['TableCell']),  # Output
                str(values[4]),  # Jumlah
                Paragraph(str(values[5]), styles['TableCell']),  # Keterangan
            ]
            task_data.append(wrapped_values)

        task_table = Table(task_data, colWidths=[25, 230, 230, 230, 45, 70])
        task_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),  # Center align all header texts
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (0, -1), 'CENTER'),  # No column
            ('ALIGN', (4, 0), (4, -1), 'CENTER'),  # Jumlah column
            ('ALIGN', (1, 1), (-1, -1), 'LEFT'),   # Text columns
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('TOPPADDING', (0, 0), (-1, 0), 7),   # Padding only for header row
            ('BOTTOMPADDING', (0, 0), (-1, 0), 7), # Padding only for header row
            ('TOPPADDING', (0, 1), (-1, -1), 1),    # Minimal padding for data rows
            ('BOTTOMPADDING', (0, 1), (-1, -1), 1),  # Minimal padding for data rows
        ]))
        elements.append(task_table)
        
        # Add signature section with right position and left-aligned text
        elements.append(Spacer(1, 35))
        
        # Create table for signature to maintain position
        signature_data = [
            [Paragraph(f"Samalantan, {self.date_picker.get_date().strftime('%d %B %Y')}", styles['Normal'])],
            [Spacer(1, 30)],  # Space for signature
            [Paragraph(self.entries["Nama:"].get(), styles['Normal'])],
            [Paragraph(f"NIP. {self.entries['NIP:'].get()}", styles['Normal'])]
        ]
        
        # Create signature table with specific width for right positioning
        signature_table = Table(signature_data, colWidths=[200])
        signature_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('LEFTPADDING', (0, 0), (-1, -1), 0),
            ('RIGHTPADDING', (0, 0), (-1, -1), 0),
        ]))
        
        # Create a table to position the signature on the right
        position_table = Table([[None, signature_table]], colWidths=[500, 200])
        elements.append(position_table)

        doc.build(elements)
        
        # Automatically open the generated PDF
        abs_path = os.path.abspath(filename)
        subprocess.Popen([abs_path], shell=True)

if __name__ == "__main__":
    root = tk.Tk()
    app = LCKHForm(root)
    root.mainloop()