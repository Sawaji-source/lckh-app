let taskCounter = 1;
let taskModal;

document.addEventListener('DOMContentLoaded', function () {
    const today = new Date();
    document.getElementById('tanggal').valueAsDate = today;
    updateHeaderYear();

    // Initialize Bootstrap Modal properly
    const modalEl = document.getElementById('taskModal');
    taskModal = new bootstrap.Modal(modalEl);

    // Add event listener for modal hidden event
    modalEl.addEventListener('hidden.bs.modal', function () {
        document.getElementById('taskForm').reset();
    });
});

function addTask() {
    try {
        taskModal.show();
    } catch (error) {
        console.error('Error showing modal:', error);
        alert('Terjadi kesalahan saat membuka form. Silakan coba lagi.');
    }
}

function saveTask() {
    const tugasPokok = document.getElementById('tugasPokok').value;
    const kegiatan = document.getElementById('kegiatan').value;
    const output = document.getElementById('output').value;
    const jumlah = document.getElementById('jumlah').value;
    const keterangan = document.getElementById('keterangan').value;

    if (!tugasPokok || !kegiatan || !output || !jumlah) {
        alert('Mohon lengkapi semua field yang diperlukan');
        return;
    }

    const tbody = document.getElementById('taskTableBody');
    const row = tbody.insertRow();

    row.innerHTML = `
        <td style="color: black">${taskCounter}</td>
        <td style="color: black">${tugasPokok}</td>
        <td style="color: black">${kegiatan}</td>
        <td style="color: black">${output}</td>
        <td style="color: black">${jumlah}</td>
        <td style="color: black">${keterangan}</td>
        <td>
            <button class="btn btn-warning btn-sm me-1" onclick="editTask(this)">Edit</button>
            <button class="btn btn-danger btn-sm" onclick="deleteTask(this)">Hapus</button>
        </td>
    `;

    taskCounter++;
    taskModal.hide();
}

// Add this new function for editing tasks
function editTask(btn) {
    const row = btn.closest('tr');
    const cells = row.cells;

    document.getElementById('tugasPokok').value = cells[1].textContent;
    document.getElementById('kegiatan').value = cells[2].textContent;
    document.getElementById('output').value = cells[3].textContent;
    document.getElementById('jumlah').value = cells[4].textContent;
    document.getElementById('keterangan').value = cells[5].textContent;

    // Store the row to be edited
    taskModal._editRow = row;
    taskModal.show();
}

// Modify saveTask to handle edits
function saveTask() {
    const tugasPokok = document.getElementById('tugasPokok').value;
    const kegiatan = document.getElementById('kegiatan').value;
    const output = document.getElementById('output').value;
    const jumlah = document.getElementById('jumlah').value;
    const keterangan = document.getElementById('keterangan').value;

    if (!tugasPokok || !kegiatan || !output || !jumlah) {
        alert('Mohon lengkapi semua field yang diperlukan');
        return;
    }

    if (taskModal._editRow) {
        // Update existing row
        const cells = taskModal._editRow.cells;
        cells[1].textContent = tugasPokok;
        cells[2].textContent = kegiatan;
        cells[3].textContent = output;
        cells[4].textContent = jumlah;
        cells[5].textContent = keterangan;
        taskModal._editRow = null;
    } else {
        // Create new row
        const tbody = document.getElementById('taskTableBody');
        const row = tbody.insertRow();
        row.innerHTML = `
            <td style="color: black">${taskCounter}</td>
            <td style="color: black">${tugasPokok}</td>
            <td style="color: black">${kegiatan}</td>
            <td style="color: black">${output}</td>
            <td style="color: black">${jumlah}</td>
            <td style="color: black">${keterangan}</td>
            <td>
                <button class="btn btn-warning btn-sm me-1" onclick="editTask(this)">Edit</button>
                <button class="btn btn-danger btn-sm" onclick="deleteTask(this)">Hapus</button>
            </td>
        `;
        taskCounter++;
    }

    taskModal.hide();
}

function deleteTask(btn) {
    const row = btn.closest('tr');
    row.remove();
    renumberTasks();
}

function renumberTasks() {
    const rows = document.getElementById('taskTableBody').getElementsByTagName('tr');
    taskCounter = 1;
    for (let row of rows) {
        row.cells[0].textContent = taskCounter++;
    }
}

function generatePDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF('l', 'mm', 'a4');

    // Get year from input date
    const inputTanggal = document.getElementById('tanggal').value;
    const year = new Date(inputTanggal).getFullYear();

    // Add title with dynamic year
    doc.setFontSize(13);
    doc.text('LAPORAN CAPAIAN KINERJA HARIAN', 149, 10, { align: 'center' });
    doc.setFontSize(12);
    doc.text('PEGAWAI PEMERINTAH DENGAN PERJANJIAN KERJA (PPPK)', 149, 15, { align: 'center' });
    doc.text(`KABUPATEN BENGKAYANG TAHUN ${year}`, 149, 20, { align: 'center' });

    // Add personal information with properly aligned text
    doc.setFontSize(11);
    const nama = document.getElementById('nama').value;
    const nip = document.getElementById('nip').value;
    const jabatan = document.getElementById('jabatan').value;
    const wilayahKerja = document.getElementById('wilayahKerja').value;

    // Split labels and values for proper alignment
    const labelX = 24;
    const colonX = 54;
    const valueX = 57;

    // Labels
    doc.text('Nama', labelX, 27);
    doc.text('NIP', labelX, 32);
    doc.text('Jabatan', labelX, 37);
    doc.text('Wilayah Kerja', labelX, 42);
    doc.text('Tanggal', labelX, 47);

    // Colons
    doc.text(':', colonX, 27);
    doc.text(':', colonX, 32);
    doc.text(':', colonX, 37);
    doc.text(':', colonX, 42);
    doc.text(':', colonX, 47);

    // Values
    doc.text(nama, valueX, 27);
    doc.text(nip, valueX, 32);
    doc.text(jabatan, valueX, 37);
    doc.text(wilayahKerja, valueX, 42);
    doc.text(
  new Date(inputTanggal).toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }),
  valueX,
  47
);

    // Add task table
    const tableRows = [];
    const rows = document.getElementById('taskTableBody').getElementsByTagName('tr');

    tableRows.push(['No', 'Tugas Pokok', 'Kegiatan', 'Output', 'Jumlah', 'Keterangan']);

    for (let row of rows) {
        const rowData = [];
        for (let i = 0; i < 6; i++) {
            rowData.push(row.cells[i].textContent);
        }
        tableRows.push(rowData);
    }

    doc.autoTable({
        startY: 52,
        head: [tableRows[0]],
        body: tableRows.slice(1),
        theme: 'striped',
        headStyles: { fillColor: [200, 200, 200], textColor: [0, 0, 0], halign:'center'},
        styles: {
            fontSize: 10,
            cellPadding: 1,
            textColor: [0, 0, 0], // This ensures black text in all cells
            lineColor: [0,0,0],
            lineWidth: 0.1,
            halign: 'justify',
            
        },
        columnStyles: {
            0: { cellWidth: 9, halign:'center' },
            1: { cellWidth: 77 },
            2: { cellWidth: 79 },
            3: { cellWidth: 75 },
            4: { cellWidth: 15, halign:'center'},
            5: { cellWidth: 25, halign:'center'}
        }
    });

    // Add signature
    // Update the signature section to use inputTanggal
    const finalY = doc.previousAutoTable.finalY +10;
    doc.setFontSize(11);
    const tanggalFormatted = new Date(inputTanggal).toLocaleDateString('id-ID', {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
});
doc.text(`Samalantan, ${tanggalFormatted}`, 200, finalY);
    doc.text(nama, 200, finalY + 20);
    doc.text(`NIP. ${nip}`, 200, finalY + 25);

    // Save the PDF
    doc.save('LCKH_Report.pdf');
}

// Add at the beginning of the file
function updateHeaderYear() {
    const tanggal = document.getElementById('tanggal').value;
    const year = new Date(tanggal).getFullYear();
    document.getElementById('headerYear').textContent = year;
}